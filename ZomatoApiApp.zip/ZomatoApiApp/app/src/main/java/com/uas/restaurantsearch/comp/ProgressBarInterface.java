package com.uas.restaurantsearch.comp;

public interface ProgressBarInterface {
    void showProgress();
    void hideProgress();
}
