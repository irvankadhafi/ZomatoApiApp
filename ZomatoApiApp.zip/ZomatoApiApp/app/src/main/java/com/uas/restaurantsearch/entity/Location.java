package com.uas.restaurantsearch.entity;

import java.io.Serializable;

public class Location implements Serializable{

    public String getAddress() {
        return address;
    }
    public String getlatitude() {return latitude;}
    public String getlongitude() {return longitude;}
    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLocality_verbose() {
        return locality_verbose;
    }

    public void setLocality_verbose(String locality_verbose) {
        this.locality_verbose = locality_verbose;
    }

    private String address, locality, city, locality_verbose, latitude, longitude;


    //Location Api response parameters...
    private long city_id;
    private String country_name, city_name;

    public long getCity_id() {
        return city_id;
    }

    public void setCity_id(long city_id) {
        this.city_id = city_id;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }
}
